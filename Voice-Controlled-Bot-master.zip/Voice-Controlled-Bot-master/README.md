# Voice-Controlled-Bot
This is for a voice controlled robotic toy car. We are using google voice to text translator for voice translation.
